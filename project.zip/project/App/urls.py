from django.urls import path
from . import views

urlpatterns = [
    path('', views.PostList.as_view(), name="home"),
    path('post/<slug:slug>/', views.DetailView.as_view(), name="post_detail"),
    path('create/', views.CreatePostView.as_view(), name='create_post'),
    path('reply/<int:post_id>/', views.reply_to_post, name='reply_to_post'),
    path('like/<slug:slug>/', views.LikeView.as_view(), name='like_post'),
]
