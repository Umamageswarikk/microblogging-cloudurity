from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy,reverse
from .models import Post, Reply
from django.views import generic
from .forms import PostForm, ReplyForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect
from django.views import View

class PostList(generic.ListView):
    queryset = Post.objects.filter(status=1).order_by('-created_on')
    template_name = 'index.html'

class DetailView(generic.DetailView):
    model = Post
    template_name = 'post_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        post_slug = self.kwargs['slug']  # Use 'slug' instead of 'pk'
        post = get_object_or_404(Post, slug=post_slug)  # Retrieve Post using slug
        total_likes = post.total_likes()
        context["total_likes"] = total_likes
        return context



class CreatePostView(LoginRequiredMixin, generic.CreateView):
    model = Post
    form_class = PostForm
    template_name = 'create_post.html'
    success_url = reverse_lazy('home')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

@login_required
def reply_to_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        form = ReplyForm(request.POST)
        if form.is_valid():
            reply = form.save(commit=False)
            reply.user = request.user
            reply.post = post
            reply.save()
            return redirect('home')
    else:
        form = ReplyForm()
    return render(request, 'reply_to_post.html', {'form': form, 'post': post})



class LikeView(View):
    def post(self, request, *args, **kwargs):
        slug = kwargs.get('post_id')
        post = get_object_or_404(Post, id=slug)
        post.likes.add(request.user)
        return HttpResponseRedirect(reverse('post_detail', args=[str(slug)]))