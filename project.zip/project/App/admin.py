from django.contrib import admin

# Register your models here.
from .models import Post,Reply


class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'slug', 'author', 'created_on', 'status')
    search_fields = ['title', 'content']
    prepopulated_fields = {'slug': ('title',)}
    list_filter = ('status', 'created_on')
    ordering = ['-created_on']

class ReplyAdmin(admin.ModelAdmin):
    list_display = ('post', 'user', 'content', 'created_at')
    search_fields = ['content', 'user__username']
    list_filter = ('created_at',)
    ordering = ['-created_at']    

admin.site.register(Post, PostAdmin)
admin.site.register(Reply, ReplyAdmin)